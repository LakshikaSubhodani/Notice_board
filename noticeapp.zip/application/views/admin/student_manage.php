<div class="admin-content">
    <a href="<?php echo base_url()?>admin/managestudent"><h4 ><i class="fa fa-fw fa-group (alias)"></i>Student Management</h4></a>
    <hr/>

    <table id="manage-student-table" class="table table-striped table-bordered" cellspacing="0" width="100%">
	<thead>
		<tr>
			<th>Enrollment ID</th>
			<th>First Name</th>
			<th>Last Name</th>
			<th>Email</th>
			<th>Faculty</th>
			<th>Action</th>
		</tr>
	</thead>

</table>

</div>