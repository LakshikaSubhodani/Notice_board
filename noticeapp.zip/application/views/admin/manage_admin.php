<div class="admin-content">
<a href="<?php echo base_url()?>admin/manageadmin"><h4><i class="fa fa-fw fa-user-plus"></i>Admin Management</h4></a>
    <hr/>

    <table id="manage-admin-table" class="table table-striped table-bordered" cellspacing="0" width="100%">
	<thead>
		<tr>
			<th>First Name</th>
			<th>Last Name</th>
			<th>Email</th>
			<th>Faculty</th>
			<th>Action</th>
		</tr>
	</thead>

</table>

</div>