


    <div id="page-wrapper">
        <div class="container-fluid">
            <!-- Page Heading -->
            <div class="row" id="main" >
                <div class="col-sm-12 col-md-12 " id="content">
                    <h3 class="dash-title">Welcome, Uva Wellassa University Notice Board</h3>
                    
                    <div class="dash-button">
                        <a href="<?php echo base_url()?>student/dashboard" target="_blank">
                        <img src="<?php echo base_url()?>assests/img/notice_borad.png" class="dash-image" alt="dash-image">
                        <p>Go to Notice Board</p>
                        </a>  
                    </div>
                </div>
            </div>
            <!-- /.row -->
        </div>
        <!-- /.container-fluid -->
    </div>
    <!-- /#page-wrapper -->
</div><!-- /#wrapper -->




<!------ Include the above in your HEAD tag ---------->

