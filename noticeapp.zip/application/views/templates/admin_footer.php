<script src="https://code.jquery.com/jquery-3.6.0.js" integrity="sha256-H+K7U5CnXl1h5ywQfKtSj8PCmoN9aaq30gDh27Xc0jk=" crossorigin="anonymous"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
<script src="https://cdn.datatables.net/1.10.25/js/jquery.dataTables.min.js" ></script>
<script src="https://cdn.datatables.net/1.10.25/js/dataTables.bootstrap.min.js" ></script>
<script type="text/javascript" src="<?php echo base_url('assests/js/bootstrap-datepicker.js')?>"></script>
<script type="text/javascript" src="<?php echo base_url('assests/js/admin/admin.js')?>"></script>
<?php echo '<script type="text/javascript" src="'. base_url($jsfile_name).'"></script>'; ?>

</body>
</html>